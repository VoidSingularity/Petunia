package net.mcberry.petunia;

import net.mcberry.berry.loader.BerryLoader;
import net.mcberry.berry.loader.BerryModInitializer;
import net.mcberry.berry.loader.ExternalLibraryCollection;
import net.mcberry.berry.loader.JarContainer;
import net.mcberry.berry.utils.StringSorter;
import net.mcberry.petunia.fabric.BerryFabricLauncher;

public class PetuniaInitializer implements BerryModInitializer {
    static JarContainer thisjar;
    static ExternalLibraryCollection fabriclib;

    @Override
    public void preinit(StringSorter sorter, JarContainer jar, String name) {
        thisjar = jar;
        sorter.addValue(name);
        sorter.addRule("berrybuiltins", name);
        fabriclib = new ExternalLibrariesInfo();
        fabriclib.initialize();
    }

    public void initialize(String[] argv) {
        // Fabric
        fabriclib.imports();
        try {
            if (BerryLoader.isDevelopment()) System.setProperty("fabric.development", "true");
            new BerryFabricLauncher();
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }
}
