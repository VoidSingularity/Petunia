rootProject.name = "petunia"

pluginManagement {
    repositories {
        mavenLocal()
        gradlePluginPortal()
        // The following maven is only for internal testing, remove this before publishing
        maven(url = "https://azfs.pages.dev/maven/")
    }
}
